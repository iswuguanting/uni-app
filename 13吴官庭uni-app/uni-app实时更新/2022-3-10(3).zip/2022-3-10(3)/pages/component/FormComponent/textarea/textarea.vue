<template>
	<view>
		<view class="smalt_page_head">
			<view class="smalt_page_head_title">textarea 多行文本</view>
		</view>
		<view class="smalt_padding_wrap">
			<view>输入区域高度自适应，不会出现滚动条</view>
			<textarea class="text_area" auto-height=""></textarea>
			<view>占位符字体是红色的</view>
			<textarea class="text_area" placeholder-style="color:#F76260" placeholder="占位符字体是红色的"></textarea>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
